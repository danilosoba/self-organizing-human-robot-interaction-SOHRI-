#!/usr/bin/env python

# Artigo BARBOSA, Danilo S.; ARAUJO, 
# Aluizio FR; GUTIERREZ-HUAMPO, 
# Eulogio. Voice commanded system for 
# navigation of mobile robots. In: 2021 
# IEEE International Conference on Systems, 
# Man, and Cybernetics (SMC). IEEE, 
# 2021. p. 1087-1092.

 

import roslib; roslib.load_manifest('rnn1vn')
import rclpy
from rclpy.node import Node
import tensorflow as tf
import librosa
import numpy as np

# Carregar a base de dados LibreSpeech
data = np.load('librespeech_data.npz')
X_train, y_train = data['X_train'], data['y_train']
X_val, y_val = data['X_val'], data['y_val']
X_test, y_test = data['X_test'], data['y_test']

# Pré-processar os dados
# Converta os sinais de áudio em espectrograma log-mel
X_train = np.array([librosa.feature.melspectrogram(x, sr=16000) for x in X_train])
X_val = np.array([librosa.feature.melspectrogram(x, sr=16000) for x in X_val])
X_test = np.array([librosa.feature.melspectrogram(x, sr=16000) for x in X_test])


# Definir o modelo RNN-LSTM
model = tf.keras.Sequential([
    tf.keras.layers.Conv1D(32, 5, activation='relu', input_shape=(time_steps, input_dim)),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Conv1D(32, 5, activation='relu'),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Conv1D(32, 5, activation='relu'),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700 return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700)),
    tf.keras.layers.Dense(1600, activation='relu'),
    tf.keras.layers.Dense(len(vocab), activation='softmax')
])

# Compilar o modelo
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Treinar o modelo
history = model.fit(X_train, y_train, batch_size=32, epochs=10, validation_data=(X_val, y_val))

# Avaliar o modelo
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=2)



# Defina um nó ROS2 para usar o modelo ASR treinado
 

class ASRNode(Node):
    def __init__(self):
        super().__init__('asr_node')
        
        # Carregar o modelo ASR treinado
        self.model = model
        
       # Configure uma assinatura para o tópico de áudio
        self.subscription = self.create_subscription(AudioMessage, 'audio', self.audio_callback, 10)
        

# Executar o nó ROS2
rclpy.init()
asr_node = ASRNode()
rclpy.spin(asr_node)