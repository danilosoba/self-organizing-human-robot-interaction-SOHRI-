#!/usr/bin/env python
# rede neural  SOM 

import numpy as np
import tensorflow as tf
import librosa

# Carregar a base de dados LibreSpeech
data = np.load('librespeech_data.npz')
X_train, y_train = data['X_train'], data['y_train']
X_val, y_val = data['X_val'], data['y_val']
X_test, y_test = data['X_test'], data['y_test']

# Pré-processar os dados
# Converta os sinais de áudio em coeficientes MFCC
X_train = np.array([librosa.feature.mfcc(x, sr=16000, n_mfcc=13) for x in X_train])
X_val = np.array([librosa.feature.mfcc(x, sr=16000, n_mfcc=13) for x in X_val])
X_test = np.array([librosa.feature.mfcc(x, sr=16000, n_mfcc=13) for x in X_test])




# Definir o modelo SOM
#As caracteristicas da entrada de tamanho 20x20
# dos dados de entrada possuem 13 características 
# e 32 intervalos de tempo, e a taxa de aprendizagem 0.001
model = tf.keras.models.Sequential([
    tf.keras.layers.Reshape((13*32,), input_shape=(13, 32)),
    tf.keras.layers.SOM(20, 20, input_shape=(13*32,), learning_rate=0.001),
    tf.keras.layers.Dense(len(np.unique(y_train)), activation='softmax')
])

# Compilar o modelo 
model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Trainar o modelo
model.fit(X_train, y_train, epochs=10, validation_data=(X_val, y_val))

# Avalie o modelo nos dados de teste
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print('Test Loss:', test_loss)
print('Test Accuracy:', test_accuracy)
