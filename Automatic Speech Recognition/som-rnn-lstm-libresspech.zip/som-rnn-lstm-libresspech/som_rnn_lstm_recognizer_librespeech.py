#!/usr/bin/env python

# rede neural hibrida RNN-lstm e SOM 

import numpy as np
import tensorflow as tf
from sklearn.datasets import fetch_openml

# Carregar  os dados de fala no banco de dados LibreSpeech
speech_data = fetch_openml(data_id=1590)
X = speech_data['data']
y = speech_data['target']

# Pré-processar os dados
X = (X - np.mean(X, axis=0)) / np.std(X, axis=0)


# Construir a camada SOM
 
 
som = SOM(n_rows=10, n_cols=10, input_len=X.shape[1])
output_som = som(tf.convert_to_tensor(X, dtype=tf.float32))

# Construa a camada RNN-LSTM

model = tf.keras.Sequential([
    tf.keras.layers.Conv1D(32, 5, activation='relu', input_shape=(time_steps, input_dim)),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Conv1D(32, 5, activation='relu'),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Conv1D(32, 5, activation='relu'),
    tf.keras.layers.MaxPooling1D(2),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700 return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700, return_sequences=True)),
    tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(700)),
    tf.keras.layers.Dense(1600, activation='relu'),
    tf.keras.layers.Dense(len(vocab), activation='softmax')
])



# Compilar o modelo
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# Treinar o modelo
history = model.fit(output_som, y, epochs=10, batch_size=32)


# Avaliar o modelo 
test_loss, test_accuracy = model.evaluate(output_som, y)

# Calcular a taxa de erro de palavra (WER)
predictions = model.predict(output_som)
wer = calculate_wer(y, predictions)

# Mostrar a acuracia e o WER
print("Test Accuracy:", test_accuracy)
print("Word Error Rate (WER):", wer)